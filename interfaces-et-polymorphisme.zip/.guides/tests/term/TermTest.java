import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

/**
 * This unit test class uses reflection to
 * check for fields and methods.
 */
public class TermTest {
  
  private static final float EPSILON = 1e-8f;
  
  private static Class<Term> testClass;
  private static Constructor<Term>[] testConstructors;
  private static Field[] testFields;
  private static Method[] testMethods;

  private static Term testInstance;
  
  private static double coefficient = -984.73;
  private static char variable = 'c';
  private static int exponent = 8;
  
  private static Class<?>[] constExpectedParams = {
    double.class, char.class, int.class };
  
  /**
   * @return Empty String if no error
   */
  private static String checkConstructor() {
    String res = "";
    
    if (testConstructors.length != 1 ||
        testConstructors[0].getModifiers() != Modifier.PUBLIC) {
      res = "Wrong modifier";
    } else {
      Class<?>[] constParams = testConstructors[0].getParameterTypes();
      if (constExpectedParams.length != constParams.length) {
        res = "Invalid number of parameters";
      } else {
        for (int i = 0; i < constParams.length; ++i) {
          if (!(constParams[i].equals(constExpectedParams[i]))) {
            res = "Invalid parameter type at position " + i;
            res += ": expected " + constExpectedParams[i] + " but found " + constParams[i];
            break;
          }
        }
      }
    }
    
    return res;
  }
  
  private static void assertConstructor() {
    String res = checkConstructor();
    if (res != "") {
      fail(res);
    }
  }
  
  @BeforeClass
  public static void setUpBeforeClass() throws Exception {
    testClass = Term.class;
    testConstructors = (Constructor<Term>[]) testClass.getDeclaredConstructors();
    testFields = testClass.getDeclaredFields();
    testMethods = testClass.getDeclaredMethods();
    
    assertConstructor();
    
    testInstance = (Term) testConstructors[0].newInstance(
      coefficient, variable, exponent);
  }
  
  private static Field getAccessibleField(String fieldName) {
    Field field = null;
    
    for(Field curField : testFields) {
      if (curField.getName().equals(fieldName)) {
        field = curField;
        field.setAccessible(true);
      }
    }
    
    return field;
  }
  
  private static Field assertField(
    String fieldName,
    Class<?> type,
    int modifier) {
    boolean foundField = false;
    Field resField = getAccessibleField(fieldName);
    if (resField != null) {
      // Test that it is the right type
      assertEquals(type, resField.getType());
      
      // Test that it is private
      assertEquals("Wrong modifier for field '" + fieldName + "'",
                   modifier, resField.getModifiers());
      
      foundField = true;
    }
    
    // Test that we found it
    assertTrue("Field '" + fieldName + "' was not found", foundField);
    return resField;
  }
  
  private static void assertMethod(
    String methodName,
    Class<?> returnType,
    int modifier,
    int paramCount) {
    boolean foundMethod = false;
    for(Method curMethod : testMethods) {
        // Check the signature
      if (curMethod.getName().equals(methodName) && curMethod.getParameterTypes().length == paramCount) {        
        // Test that it is the right return type
        assertEquals(returnType, curMethod.getReturnType());
        
        // Test that it is public
        assertEquals("Wrong modifier for method '" + methodName + "'",
                     modifier, curMethod.getModifiers());
        
        foundMethod = true;
        break;
      }
    }
    
    // Test that we found it
    assertTrue("Method '" + methodName + "' was not found", foundMethod);
  }
  
  @Test
  public void testConstructor1() throws IllegalAccessException {
    assertConstructor();
    
    // Check values
    assertEquals(coefficient, getAccessibleField("coefficient").get(testInstance));
    assertEquals(variable, getAccessibleField("variable").get(testInstance));
    assertEquals(exponent, getAccessibleField("exponent").get(testInstance));
  }
  
  @Test
  public void testConstructor2() {
    Term testTerm = new Term(-21.78, 'k', 1);
    
    // Check values
    assertEquals(-21.78, testTerm.getCoefficient(), EPSILON);
    assertEquals('k', testTerm.getVariable());
    assertEquals(1, testTerm.getExponent());
  }
  
  @Test
  public void testCoefficient() throws IllegalAccessException {
    // Check that field exists
    Field testField = assertField(
      "coefficient", double.class, Modifier.PRIVATE);
    double previousValue = (double)testField.get(testInstance);
    
    // Check that getter exists
    assertMethod("getCoefficient", double.class, Modifier.PUBLIC, 0);
    
    // Change field value
    double testValue = 7561.834;
    testField.set(testInstance, testValue);
    
    // Test getter
    assertEquals(testValue, testInstance.getCoefficient(), EPSILON);
    
    // Reset field value
    testField.set(testInstance, previousValue);
  }
  
  @Test
  public void testVariable() throws IllegalAccessException {
    // Check that field exists
    Field testField = assertField(
      "variable", char.class, Modifier.PRIVATE);
    char previousValue = (char)testField.get(testInstance);
    
    // Check that getter exists
    assertMethod("getVariable", char.class, Modifier.PUBLIC, 0);
    
    // Change field value
    char testValue = 'i';
    testField.set(testInstance, testValue);
    
    // Test getter
    assertEquals(testValue, testInstance.getVariable());
    
    // Reset field value
    testField.set(testInstance, previousValue);
  }
  
  @Test
  public void testExponent() throws IllegalAccessException {
    // Check that field exists
    Field testField = assertField(
      "exponent", int.class, Modifier.PRIVATE);
    int previousValue = (int)testField.get(testInstance);
    
    // Check that getter exists
    assertMethod("getExponent", int.class, Modifier.PUBLIC, 0);
    
    // Change field value
    int testValue = 13;
    testField.set(testInstance, testValue);
    
    // Test getter
    assertEquals(testValue, testInstance.getExponent());
    
    // Reset field value
    testField.set(testInstance, previousValue);
  }
  
}
