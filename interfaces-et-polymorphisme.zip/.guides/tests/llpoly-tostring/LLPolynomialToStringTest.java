import static org.junit.Assert.*;

import org.junit.Test;

public class LLPolynomialToStringTest {
  
  private Term term1 = new Term(75.8, 'c', 7);
  private Term term2 = new Term(0.14, ' ', 0);
  private Term term3 = new Term(-21.4, 'i', 1);
  private Term term4 = new Term(16.5, 'z', 2);
  private Term term5 = new Term(75.8, 'c', 1);
  private Term term6 = new Term(31.7, 'z', 2);
  private Term term7 = new Term(66.8, 'k', 1);
  private Term term8 = new Term(-13.4, 'z', 2);
  
  private static void assertToString(Term[] terms,
    String expected) {
    Polynomial poly = new LLPolynomial();
    for (Term t : terms) {
      assertTrue(poly.addTerm(t));
    }
    assertEquals(expected, poly.toString());
  }
  
  @Test
  public void testToString1() { // three terms
    assertToString(new Term[] {
      term1,
      term2,
      term4
    }, "75.8c^7+0.14+16.5z^2");
  }
  
  @Test
  public void testToString2() { // six terms
    assertToString(new Term[] {
      term1,
      term2,
      term4,
      term5,
      term6,
      term7
    }, "75.8c^7+0.14+16.5z^2+75.8c+31.7z^2+66.8k");
  }
  
  @Test
  public void testToString3() { // single term
    assertToString(new Term[] {
      term7
    }, "66.8k");
  }
  
  @Test
  public void testToString4() { // negative (middle)
    assertToString(new Term[] {
      term1,
      term2,
      term3,
      term4
    }, "75.8c^7+0.14-21.4i+16.5z^2");
  }
  
  @Test
  public void testToString5() { // negatives (front and last)
    assertToString(new Term[] {
      term3,
      term1,
      term2,
      term4,
      term8
    }, "-21.4i+75.8c^7+0.14+16.5z^2-13.4z^2");
  }
  
}
