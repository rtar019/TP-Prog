import static org.junit.Assert.*;

import java.util.Comparator;
import java.lang.reflect.Type;
import org.junit.Test;

public class TermComparatorTest {
  
  private TermComparator comp = new TermComparator();
  
  private Term term1 = new Term(75.8, 'c', 7);
  private Term term2 = new Term(0.14, ' ', 0);
  private Term term3 = new Term(-21.4, 'i', 1);
  private Term term4 = new Term(16.5, 'z', 2);
  private Term term5 = new Term(-62.9, 'c', 8);
  private Term term6 = new Term(31.7, 'z', 2);
//  private Term term7 = new Term(66.8, 'i', 1);
  private Term term8 = new Term(-13.4, 'z', 1);
  private Term term9 = new Term(4.9, ' ', 0);
  private Term term10 = new Term(-1.5, ' ', 0);
  
  @Test
  public void testClass() {
    Class<TermComparator> testClass = TermComparator.class;
    Class<?>[] interfaces = testClass.getInterfaces();
    //Type[] interfaces2 = testClass.getGenericInterfaces();
    assertEquals(1, interfaces.length);
    assertEquals(Comparator.class, interfaces[0]);
  }
  
  @Test
  public void testCompare1() { // variables
    assertTrue(comp.compare(term1, term3) < 0);
    assertTrue(comp.compare(term4, term5) > 0);
  }
  
  @Test
  public void testCompare2() { // exponents & undefined variables
    assertTrue(comp.compare(term6, term8) < 0);
    assertTrue(comp.compare(term9, term10) == 0);
  }
  
  @Test
  public void testCompareWithSort() { // with defined vs. undefined comparison
    LLPolynomial poly = new LLPolynomial();
    poly.addTerm(term1);
    poly.addTerm(term2);
    poly.addTerm(term3);
//    poly.addTerm(term4);
    poly.addTerm(term5);
    poly.addTerm(term6);
//    poly.addTerm(term7);
    poly.addTerm(term8);
    
    poly.sort();
    assertEquals(
      "-62.9c^8+75.8c^7-21.4i+31.7z^2-13.4z+0.14",
      poly.toString());
  }
  
}
