import static org.junit.Assert.*;

import org.junit.Test;

public class TermToStringTest {
  
  private static void assertToString(
    double coefficient, char variable, int exponent,
    String expected) {
    Term test = new Term(coefficient, variable, exponent);
    assertEquals(expected, test.toString());
  }
  
  @Test
  public void testToString1() {
    assertToString(3.7, 'y', 5, "3.7y^5");
  }
  
  @Test
  public void testToString2() {
    assertToString(-2.1, 'i', 11, "-2.1i^11");
  }
  
  @Test
  public void testToString3() {
    assertToString(4.0, 'a', 1, "4.0a");
  }
  
  @Test
  public void testToString4() {
    assertToString(-78.9, 'm', 1, "-78.9m");
  }
  
  @Test
  public void testToString5() {
    assertToString(-8.9, ' ', 0, "-8.9");
  }
  
}
