import static org.junit.Assert.*;

import org.junit.Test;

public class ExceptionTest {
  
  private final static String ERROR_MESSAGE = "Terms with a zero coefficient are invalid";
  
  @Test(expected = ZeroCoefficientException.class)
  public void testConstructorError() {
    Term test = new Term(0.0, 'y', 3);
  }
  
  @Test
  public void testConstructorMessage1() {
    boolean exceptionThrown = false;
    try {
      Term test = new Term(0.0, 'i', 4);
    } catch (ZeroCoefficientException zce) {
      exceptionThrown = true;
      assertEquals(ERROR_MESSAGE, zce.getMessage());
    }
    assertTrue("No exception thrown", exceptionThrown);
  }
  
  @Test
  public void testConstructorValid1() {
    Term test = new Term(-0.1, ' ', 0);
  }
  
  @Test
  public void testConstructorMessage2() {
    boolean exceptionThrown = false;
    try {
      Term test = new Term(0.0, 'z', 1);
    } catch (ZeroCoefficientException zce) {
      exceptionThrown = true;
      assertEquals(ERROR_MESSAGE, zce.getMessage());
    }
    assertTrue("No exception thrown", exceptionThrown);
  }
  
  @Test
  public void testConstructorValid2() {
    Term test = new Term(0.1, 'x', 1);
  }
  
}
