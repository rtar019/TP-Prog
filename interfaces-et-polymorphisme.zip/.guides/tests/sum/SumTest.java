import static org.junit.Assert.*;

import java.util.List;
import org.junit.Test;

public class SumTest {
  
  private static final float EPSILON = 1e-8f;
  
  private Term term1 = new Term(75.8, 'c', 7);
  private Term term2 = new Term(0.14, ' ', 0);
  private Term term3 = new Term(-21.4, 'i', 1);
  private Term term4 = new Term(16.5, 'z', 2);
  private Term term5 = new Term(-62.9, 'c', 7);
  private Term term6 = new Term(31.7, 'z', 2);
  private Term term7 = new Term(66.8, 'i', 1);
  private Term term8 = new Term(-13.4, 'z', 2);
  private Term term9 = new Term(-0.14, ' ', 0);
  private Term term10 = new Term(-12.9, 'c', 7);
  
  private static String convertToString(List<Term> terms) {
    String res = "[ ";
    for (Term t : terms) {
      res += t + " ";
    }
    res += "]";
    return res;
  }
  
  private static void assertContains(Term[] expected, List<Term> terms) {
    String listOfTerms = convertToString(terms);
    
    int nearZeroTermCount = 0; // For precision errors
    for (Term term : terms) {
      if (term.getCoefficient() > -EPSILON &&
          term.getCoefficient() < EPSILON) {
        ++nearZeroTermCount;
      }
    }
        
    for (Term expectedTerm : expected) {
      boolean found = false;
      for (Term term : terms) {
        if (term.getCoefficient() > expectedTerm.getCoefficient() - EPSILON &&
            term.getCoefficient() < expectedTerm.getCoefficient() + EPSILON &&
            term.getVariable() == expectedTerm.getVariable() &&
            term.getExponent() == expectedTerm.getExponent()) {
          found = true;
          break;
        }
      }
      assertTrue("Term " + expectedTerm + " was not found: " + listOfTerms, found);
    }
    assertEquals(listOfTerms, expected.length, terms.size() - nearZeroTermCount);
  }
  
  private static void assertSum(Polynomial poly1, Polynomial poly2,
    Term[] expected) {
    Polynomial res = PolynomialToolbox.sum(poly1, poly2);
    assertContains(expected, res.getAllTerms());
  }
  
  @Test
  public void testSum1() { // One sum
    // 5y3
		Term t2 = new Term(5.0, 'y', 3);
    Polynomial poly1 = new LLPolynomial();
		poly1.addTerm(t2);
		
		// 2y3
		Term t4 = new Term(2.0, 'y', 3);
    Polynomial poly2 = new LLPolynomial();
		poly2.addTerm(t4);
    
    // 7.0x^2+3.0x^3+7.0y^3
    assertSum(poly1, poly2, new Term[] {
      new Term(7.0, 'y', 3)
    });
  }
  
  @Test
  public void testSum2() { // Two sums
    // 3x2 + 5y3
		Term t1 = new Term(3.0, 'x', 2);
		Term t2 = new Term(5.0, 'y', 3);
    Polynomial poly1 = new LLPolynomial();
		poly1.addTerm(t1);
		poly1.addTerm(t2);
		
		// 2y3 + 3x3 + 4x2
		Term t4 = new Term(2.0, 'y', 3);
		Term t5 = new Term(3.0, 'x', 3);
		Term t6 = new Term(4.0, 'x', 2);
    Polynomial poly2 = new LLPolynomial();
		poly2.addTerm(t4);
		poly2.addTerm(t5);
		poly2.addTerm(t6);
    
    // 7.0x^2+3.0x^3+7.0y^3
    assertSum(poly1, poly2, new Term[] {
      new Term(7.0, 'x', 2),
      new Term(3.0, 'x', 3),
      new Term(7.0, 'y', 3)
    });
  }
  
  @Test
  public void testSum3() { // Summed and simplified terms
    // 3x2 + 5y3 + 2
		Term t1 = new Term(3.0, 'x', 2);
		Term t2 = new Term(5.0, 'y', 3);
		Term t3 = new Term(2.0, ' ', 0);
    Polynomial poly1 = new LLPolynomial();
		poly1.addTerm(t1);
		poly1.addTerm(t2);
		poly1.addTerm(t3);
		
		// 2y3 + 3x3 + 4x2 - 2
		Term t4 = new Term(2.0, 'y', 3);
		Term t5 = new Term(3.0, 'x', 3);
		Term t6 = new Term(4.0, 'x', 2);
		Term t7 = new Term(-2.0, ' ', 0);
    Polynomial poly2 = new LLPolynomial();
		poly2.addTerm(t4);
		poly2.addTerm(t5);
		poly2.addTerm(t6);
		poly2.addTerm(t7);
    
    // 7.0x^2+3.0x^3+7.0y^3
    assertSum(poly1, poly2, new Term[] {
      new Term(7.0, 'x', 2),
      new Term(3.0, 'x', 3),
      new Term(7.0, 'y', 3)
    });
  }
  
  @Test
  public void testSum4() { // Summed and simplified terms
		Term t1 = new Term(3.2, 'x', 5);
		Term t2 = new Term(-5.0, 'k', 3);
		Term t3 = new Term(2.0, ' ', 0);
    Polynomial poly1 = new LLPolynomial();
		poly1.addTerm(t1);
		poly1.addTerm(t2);
		poly1.addTerm(t3);
		
		Term t4 = new Term(-2.5, 'k', 3);
		Term t5 = new Term(-21.8, 'x', 10);
		Term t6 = new Term(4.1, 'x', 5);
		Term t7 = new Term(-2.0, ' ', 0);
    Polynomial poly2 = new LLPolynomial();
		poly2.addTerm(t4);
		poly2.addTerm(t5);
		poly2.addTerm(t6);
		poly2.addTerm(t7);
    
    assertSum(poly1, poly2, new Term[] {
      new Term(7.3, 'x', 5),
      new Term(-21.8, 'x', 10),
      new Term(-7.5, 'k', 3)
    });
  }
  
  @Test
  public void testSum5() { // No summed/simplified term
    // 3x2 + 2
		Term t1 = new Term(3.0, 'x', 2);
		Term t3 = new Term(2.0, ' ', 0);
    Polynomial poly1 = new LLPolynomial();
		poly1.addTerm(t1);
		poly1.addTerm(t3);
		
		// 2y3 + 3x3
		Term t4 = new Term(2.0, 'y', 3);
		Term t5 = new Term(3.0, 'x', 3);
    Polynomial poly2 = new LLPolynomial();
		poly2.addTerm(t4);
		poly2.addTerm(t5);
    
    // 7.0x^2+3.0x^3+7.0y^3
    assertSum(poly1, poly2, new Term[] {
      new Term(3.0, 'x', 2),
      new Term(2.0, ' ', 0),
      new Term(2.0, 'y', 3),
      new Term(3.0, 'x', 3)
    });
  }
  
}
