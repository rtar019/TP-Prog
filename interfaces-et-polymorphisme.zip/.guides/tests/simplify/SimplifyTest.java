import static org.junit.Assert.*;

import java.util.List;
import org.junit.Test;

public class SimplifyTest {
  
  private static final float EPSILON = 1e-8f;
  
  // Terms with round integer values
  private Term termInt3 = new Term(-21.0, 'i', 1);
  private Term termInt5 = new Term(-62.0, 'c', 7);
  private Term termInt7 = new Term(66.0, 'i', 1);
  
  private Term term1 = new Term(75.8, 'c', 7);
  private Term term2 = new Term(0.14, ' ', 0);
  private Term term3 = new Term(-21.4, 'i', 1);
  private Term term4 = new Term(16.5, 'z', 2);
  private Term term5 = new Term(-62.9, 'c', 7);
  private Term term6 = new Term(31.7, 'z', 2);
  private Term term7 = new Term(66.8, 'i', 1);
  private Term term8 = new Term(-13.4, 'z', 2);
  private Term term9 = new Term(-0.14, ' ', 0);
  private Term term10 = new Term(-12.9, 'c', 7);
  
  private static String convertToString(List<Term> terms) {
    String res = "[ ";
    for (Term t : terms) {
      res += t + " ";
    }
    res += "]";
    return res;
  }
  
  private static void assertContains(Term[] expected, List<Term> terms) {
    String listOfTerms = convertToString(terms);
    
    int nearZeroTermCount = 0; // For precision errors
    for (Term term : terms) {
      if (term.getCoefficient() > -EPSILON &&
          term.getCoefficient() < EPSILON) {
        ++nearZeroTermCount;
      }
    }
        
    for (Term expectedTerm : expected) {
      boolean found = false;
      for (Term term : terms) {
        if (term.getCoefficient() > expectedTerm.getCoefficient() - EPSILON &&
            term.getCoefficient() < expectedTerm.getCoefficient() + EPSILON &&
            term.getVariable() == expectedTerm.getVariable() &&
            term.getExponent() == expectedTerm.getExponent()) {
          found = true;
          break;
        }
      }
      assertTrue("Term " + expectedTerm + " was not found: " + listOfTerms, found);
    }
    assertEquals(listOfTerms, expected.length, terms.size() - nearZeroTermCount);
  }
  
  private static void assertSimplify(Term[] terms,
    Term[] expected) {
    Polynomial poly = new LLPolynomial();
    for (Term t : terms) {
      assertTrue(poly.addTerm(t));
    }
    Polynomial res = PolynomialToolbox.simplify(poly);
    assertContains(expected, res.getAllTerms());
  }
  
  @Test
  public void testSimplify1() { // one combine (2 terms) i1
    assertSimplify(new Term[] {
      termInt3,
      termInt5,
      termInt7
    }, new Term[] {
      new Term(45.0, 'i', 1),
      new Term(-62.0, 'c', 7)
    });
  }
  
  @Test
  public void testSimplify2() { // two combines (5 terms) z2
    assertSimplify(new Term[] {
      term3,
      term4,
      term5,
      term6,
      term7,
      term8
    }, new Term[] {
      new Term(45.4, 'i', 1),
      new Term(34.8, 'z', 2),
      new Term(-62.9, 'c', 7)
    });
  }
  
  @Test
  public void testSimplify3() { // no change
    assertSimplify(new Term[] {
      term3,
      term4,
      term9
    }, new Term[] {
      new Term(-21.4, 'i', 1),
      new Term(16.5, 'z', 2),
      new Term(-0.14, ' ', 0)
    });
  }
  
  @Test
  public void testSimplify4() { // one removal
    assertSimplify(new Term[] {
      term1,
      term3,
      term4,
      term5,
      term9,
      term10
    }, new Term[] {
      new Term(-21.4, 'i', 1),
      new Term(16.5, 'z', 2),
      new Term(-0.14, ' ', 0)
    });
  }
  
  @Test
  public void testSimplify5() { // combine and removals
    assertSimplify(new Term[] {
      term1,
      term2,
      term3,
      term4,
      term5,
      term6,
      term7,
      term8,
      term9,
      term10
    }, new Term[] {
      new Term(45.4, 'i', 1),
      new Term(34.8, 'z', 2)
    });
  }
  
}
