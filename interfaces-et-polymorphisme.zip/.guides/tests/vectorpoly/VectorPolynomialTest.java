import static org.junit.Assert.*;

import java.util.List;
import org.junit.Before;
import org.junit.Test;

public class VectorPolynomialTest {
  
  private Polynomial poly;
  private Term term1 = new Term(75.8, 'c', 7);
  private Term term2 = new Term(0.14, ' ', 0);
  private Term term3 = new Term(-21.4, 'i', 1);
  private Term term4 = new Term(16.5, 'z', 2);
  private int termCount = 4;
  private Term term5 = new Term(75.8, 'c', 1);
  private Term term6 = new Term(31.7, 'z', 2);
  private Term term7 = new Term(66.8, 'k', 1);
  private Term term8 = new Term(-13.4, 'z', 2);
  
  // Test values
  private int emptySize = 0;
  private int fullSize = 0;
  private int minusOneSize = 0;
  private boolean addRes = false;
  private boolean validRemoveRes = false;
  private boolean invalidRemoveRes = false;
  
  private String convertToString(List<Term> terms) {
    String res = "[ ";
    for (Term t : terms) {
      res += t + " ";
    }
    res += "]";
    return res;
  }
  
  private void assertContains(Term[] expected, List<Term> terms) {
    String listOfTerms = convertToString(terms);
    assertEquals(listOfTerms, expected.length, terms.size());
    
    for (Term expectedTerm : expected) {
      boolean found = false;
      for (Term term : terms) {
        if (term.getCoefficient() == expectedTerm.getCoefficient() &&
            term.getVariable() == expectedTerm.getVariable() &&
            term.getExponent() == expectedTerm.getExponent()) {
          found = true;
          break;
        }
      }
      assertTrue("Term " + expectedTerm + " was not found", found);
    }
  }
  
  private static void assertToString(Term[] terms,
    String expected) {
    Polynomial poly = new VectorPolynomial();
    for (Term t : terms) {
      assertTrue(poly.addTerm(t));
    }
    assertEquals(expected, poly.toString());
  }
  
  @Before
  public void setUpBefore() {
    poly = new VectorPolynomial();
    emptySize = poly.getTermCount();
    addRes = poly.addTerm(term1);
    addRes = addRes && poly.addTerm(term2);
    addRes = addRes && poly.addTerm(term3);
    addRes = addRes && poly.addTerm(term4);
    fullSize = poly.getTermCount();
    
    validRemoveRes = poly.removeTerm(term3);
    invalidRemoveRes = poly.removeTerm(new Term(42.8, 'k', 2));
    minusOneSize = poly.getTermCount();
  }
  
  @Test
  public void testAddTerm() {
    assertTrue(addRes);
    assertEquals(termCount, fullSize);
  }
  
  @Test
  public void testRemoveTerm() {
    assertTrue(validRemoveRes);
    assertFalse(invalidRemoveRes);
    assertEquals(termCount - 1, minusOneSize);
  }
  
  @Test
  public void testGetTermCount() {
    assertEquals(0, emptySize);
    assertEquals(termCount, fullSize);
    assertEquals(termCount - 1, minusOneSize);
  }
  
  @Test
  public void testGetVariables1() {
    List<Character> variables = poly.getVariables();
    
    assertEquals(3, variables.size());
    assertTrue(variables.contains('c'));
    assertTrue(variables.contains(' '));
    assertTrue(variables.contains('z'));
  }
  
  @Test
  public void testGetVariables2() {
    poly.addTerm(term5);
    poly.addTerm(term6);
    poly.addTerm(term7);
    poly.addTerm(term8);
    List<Character> variables = poly.getVariables();
    
    assertEquals(4, variables.size());
    assertTrue(variables.contains('c'));
    assertTrue(variables.contains(' '));
    assertTrue(variables.contains('z'));
    assertTrue(variables.contains('k'));
  }
  
  @Test
  public void testGetExponents1() {
    List<Integer> exponents = poly.getExponents();
    
    assertEquals(3, exponents.size());
    assertTrue(exponents.contains(7));
    assertTrue(exponents.contains(0));
    assertTrue(exponents.contains(2));
  }
  
  @Test
  public void testGetExponents2() {
    poly.addTerm(term5);
    poly.addTerm(term6);
    poly.addTerm(term7);
    poly.addTerm(term8);
    List<Integer> exponents = poly.getExponents();
    
    assertEquals(4, exponents.size());
    assertTrue(exponents.contains(7));
    assertTrue(exponents.contains(0));
    assertTrue(exponents.contains(2));
    assertTrue(exponents.contains(1));
  }
  
  @Test
  public void testGetTerms1() {
    poly.addTerm(term5);
    poly.addTerm(term6);
    poly.addTerm(term7);
    poly.addTerm(term8);
    List<Term> terms = poly.getTerms('z', 2);
    
    assertContains(new Term[] {
      term4,
      term6,
      term8
    }, terms);
  }
  
  @Test
  public void testGetTerms2() {
    poly.addTerm(term5);
    poly.addTerm(term6);
    poly.addTerm(term7);
    poly.addTerm(term8);
    List<Term> terms = poly.getTerms('c', 1);
    
    assertContains(new Term[] {
      term5
    }, terms);
  }
  
  @Test
  public void testGetAllTerms() {
    assertContains(new Term[] {
      term1,
      term2,
      term4
    }, poly.getAllTerms());
  }
  
  @Test
  public void testToString1() { // six terms
    assertToString(new Term[] {
      term1,
      term2,
      term4,
      term5,
      term6,
      term7
    }, "75.8c^7+0.14+16.5z^2+75.8c+31.7z^2+66.8k");
  }
  
  @Test
  public void testToString2() { // negatives (front and last)
    assertToString(new Term[] {
      term3,
      term1,
      term2,
      term4,
      term8
    }, "-21.4i+75.8c^7+0.14+16.5z^2-13.4z^2");
  }
   
}
