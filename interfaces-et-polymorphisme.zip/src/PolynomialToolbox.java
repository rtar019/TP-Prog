public class PolynomialToolbox {
  
  public static Polynomial simplify(Polynomial poly) {
    return null;
  }
  
  public static Polynomial sum(Polynomial poly1, Polynomial poly2) {
    return null;    
  }
  
}
